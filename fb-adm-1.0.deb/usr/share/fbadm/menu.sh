#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

REQ1=$(which notify-send)
req1="$REQ1"

clear

if [ $req1 = "/usr/bin/notify-send" ]
then
	echo "REQ1=true"
	clear
else
	echo "REQ1=false"
	clear
	sudo apt-get -y install notify-send
fi

clear

notify-send --urgency="critical" --icon="/usr/share/fbadm/adm.svg" "Facebook URL.." "http://www.facebook.com/apollondma"

clear

sensible-browser --new-window="https://m.me/apollondma"

clear


